import math

#fungsi awal
def fungsi (x):
    return x*math.sin(x)

#turunan fungsi
def turunan(x):
    return math.sin(x) + x*math.cos(x)
x0=1.0
exact = turunan(x0)

#perhitungan nilai
h = 0.001
df_forward = (fungsi(x0 + h) - fungsi(x0))/h
df_backward = (fungsi(x0) - fungsi(x0-h))/h
df_center = (fungsi(x0+h) - fungsi(x0-h))/(2*h)
err_forward = math.fabs(df_forward-exact)
err_back = math.fabs(df_backward-exact)
err_center = math.fabs(df_center-exact)

#tampilan
print('df(x0)_exact = ', exact)
print('df(x0)_forward = ', df_forward, 'forward error = ', err_forward)
print('df(x0)_backward = ', df_backward, 'backward error = ', err_back)
print('df(x0)_center = ', df_center, 'center error = ', err_center)