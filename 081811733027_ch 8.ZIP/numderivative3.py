import numpy

#data
x = ([1.2, 1.4, 1.6, 1.8])
fx = ([0.8333, 0.7143, 0.6250, 0.5556])
hasil = numpy.poly1d([0.0])
#menentukan persamaan data
for i in range(0, len(x)):
    numer = numpy.poly1d([1.0])
    denumer = 1.0
    for j in range(0, len(x)):
        if i != j:
            numer = numer*numpy.poly1d([1.0, -x[j]])
            denumer = denumer*(x[i]-x[j])
    hasil = hasil+(numer/denumer)*fx[i]
print('persamaan dari data ini adalah = ')
print(hasil)
n_ke1=1.2
n_ke2=1.4
n_ke3=1.6
n_ke4=1.8

a = n_ke2 #ubah disini untuk mencari nilai ke n yang lain
y = (-0.2042*(a**3)) + (1.229*(a**2)) - (2.753*a) + (2.72)

b = a+0.2
yy = (-0.2042*(b**3)) + (1.229*(b**2)) - (2.753*b) + (2.72)

c = a-0.2
yyy = (-0.2042*(c**3)) + (1.229*(c**2)) - (2.753*c) + (2.72)

#perhitungan nilai
h = 0.001
df_forward = (yy - y)/h
df_backward = (y - yyy)/h
df_center = (yy - yyy)/(2*h)

#tampilan
print('df(x0)_forward = ', df_forward)
print('df(x0)_backward = ', df_backward)
print('df(x0)_center = ', df_center)