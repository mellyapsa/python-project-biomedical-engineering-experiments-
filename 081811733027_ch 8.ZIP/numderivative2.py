import numpy
#data
x = ([1.2, 1.4, 1.6, 1.8])
fx = ([0.8333, 0.7143, 0.6250, 0.5556])
hasil = numpy.poly1d([0.0])
#menentukan persamaan data
for i in range(0, len(x)):
    numer = numpy.poly1d([1.0])
    denumer = 1.0
    for j in range(0, len(x)):
        if i != j:
            numer = numer*numpy.poly1d([1.0, -x[j]])
            denumer = denumer*(x[i]-x[j])
    hasil = hasil+(numer/denumer)*fx[i]
print('persamaan dari data ini adalah = ')
print(hasil)
a = 1.5
y = (-0.2042*(a**3)) + (1.229*(a**2)) - (2.753*a) + (2.72)

#perhitungan nilai
x0 = 1.5
for i in range (0, len(x)-1):
    if x0<x[i+1] and x0>x[i]:
        y1 = y
        y2= fx[i+1]
        y3 = fx[i-1]
h = 0.1
df_forward = (y2 - y1)/h
df_backward = (y1 - y3)/h
df_center = (y2 - y3)/(2*h)

#tampilan
print('df(x0)_forward = ', df_forward)
print('df(x0)_backward = ', df_backward)
print('df(x0)_center = ', df_center)