#dwi melly aprilia sari (081811733027)
import math
L=91.44
mu=0.01
d=0.1
R=10
rho=1
alpha=64*L*mu/((d**2)*rho)
g=981
F = lambda x:(1/(-alpha + math.sqrt((alpha**2)+(8*g*(x+L)))))
a=5
b=50
seg=8
h=(b-a)/seg
x=[]
fx=[]

for i in range (0, seg+1):
    x.append(a)
    a+=h
    fxi=F(x[i])
    fx.append(fxi)
print('x = ',x)
print('f(x) = ',fx)
m=round(len(x)/2)

Dh=[]
for j in range (1,m):
    segment=int((x[len(x)-1]-x[0])/(j*h))
    print('------------------')
    print('segment = ',segment)
    print('------------------')
    jum=0
    for k in range (1,segment):
        hh =int((len(x)-1)/segment)
        jum=jum+fx[k*hh]
        print(fx[k*hh])
    print('orde h= ', hh)
    Dhi=((hh*h)/2*(fx[0]+2*jum+fx[len(x)-1]))
    print('Dh = ',Dhi)
    Dh.append(Dhi)
print('D(h) = ', Dh)
p=len(Dh)
r=-2
s=0
e=2
if p>1:
    for o in range(0, p - 1):
        r += 2
        s += 2
        e += 2
        f = []
        seg += 2
        for l in range(0, p - (o + 1)):
            fx_integ = Dh[l] + ((Dh[l] - Dh[l + 1]) / (2 ** seg - 1))
            print('f(x) integral', l, fx_integ)
            f.append(fx_integ)
        error = fx_integ - 0.574948166362027
        t = ((8 * R ** 2) / d ** 2) * fx_integ
        print('Integrasi Richardson', f)
        q = len(f)
        print('error = ', error)
else:
    print('Integrasi Richardson\t= ', Dh)
    error = Dh - 0.574948166362027
    print('error = ', error)
print('t = ', t)
