#dwi melly aprilia sari (081811733027)
import numpy as np
import pylab
def euler(t,y,dt,derivs):
    y_next=y+derivs(t,y)*dt
    return y_next

dt=0.1
y1=10.0
y2=100.0
y3=0.0
N=60

d=0.5
c=3.0
k=2*(10**-4)
Ne=60
h=0.1
a=0
b=5
N=round((b-a)/h)
Ti0=10
T0=250
V10=100
Vx0=0
t0=0

t=np.linspace(0,5,N)
y=np.zeros([int(N),3])
y[0,0]=y1
y[0,1]=y2
y[0,2]=y3

def HIV(t,y):
    g0=k*V10*y[1]-d*y[0]
    g1=-c*y[1]
    g2=Ne*d*y[0]-c*y[2]
    return np.array([g0,g1,g2])
for j in range (int(N)-1):
    y[j+1]=euler(t[j],y[j],dt,HIV)
Tdata=[y[j,0]for j in range (int(N))]
v1data=[y[j,1]for j in range (int(N))]
vxdata=[y[j,2]for j in range (int(N))]
print('T = ', Tdata[5])
print('V1 = ', v1data[5])
print('Vx = ', vxdata[5])
print('time = ', t[1:5])

pylab.figure(1)
pylab.plot(t,Tdata,'o')
pylab.xlabel('time')
pylab.ylabel('T*')

pylab.figure(2)
pylab.plot(t,vxdata,'k')
pylab.xlabel('time')
pylab.ylabel('v1')

pylab.figure(3)
pylab.plot(t,vxdata,'g')
pylab.xlabel('time')
pylab.ylabel('vx')
pylab.show()