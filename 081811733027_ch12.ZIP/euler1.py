#dwi melly aprilia sari (081811733027)
import math
import matplotlib.pyplot as plt

def euler(t,w):
    f=((w+6*10**(-5)*math.exp(-t/4))/4)*math.exp(-t/4)
    return f
def exact (t):
    q=6*(10**(-5))*(1-math.exp(-t/4))
    return q

a=0
b=2
h=0.1
w0=0.0
x0=0.0
N=round((b-a)/h)
y0=exact(x0)
print('h =', h)
print('x = ', x0, '|', 'y = ', y0)
y=w0
x=x0
ti=[]
wi=[]
yi=[]

for i in range(0,N):
    y=y+h*euler(x,y)
    y_exact=exact(b)
    error=math.fabs(y-y_exact)
    x=x+h
    print('x = ', round(x,1), '|', 'y = ',y, '|', 'error = ', error)
    ti.append(x)
    wi.append(y)
    yi.append(y)
plt.plot(ti,yi, 'o')
plt.plot(ti,wi,'k-')
plt.xlabel('nilai y')
plt.ylabel('nilai x')
plt.title('metode euler')
plt.show()
