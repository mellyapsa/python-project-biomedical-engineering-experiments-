#dwi melly aprilia sari / 081811733027
from numpy import*
import pylab
def f(t,w):
    y=w
    return y
def f2(t,w):
    rs=1.1
    rf=1
    g=981
    mu=3.5e-2
    a=10e-4
    return (((rs-rf)/rs)*g)-((9*mu*w)/(2*a**3*rs))

#inisialisasi
a=0
b=0.001
h=0.0001
N=round((b-a)/h)
t=0
w1=0
w2=0
wf1=[]
wf2=[]
ti=[]
print('n = ',N)
#perhtungan runge-kutta
for i in range (0,N):
    k1f=h*(f(t,w1))
    k2f=h*(f(t+(h/2),w1+(k1f/2)))
    k3f=h*(f(t+h/2,w1+k2f/2))
    k4f=h*(f(t+h,w1+k3f))
    w1=w1+(k1f+2*k2f+2*k3f+k4f)/6

    k1f2=h*(f2(t,w2))
    k2f2=h*(f2(t+(h/2),w2+(k1f2/2)))
    k3f2=h*(f2(t+h/2,w2+k2f2/2))
    k4f2=h*(f2(t+h,w2+k3f2))
    w2=w2+(k1f2+2*k2f2+2*k3f2+k4f2)/6
    t+=h
    wf1.append(w1)
    wf2.append(w2)
    ti.append(t)

#plot hasil
pylab.plot(ti,wf1, 'r-')
pylab.plot(ti,wf2, 'o')
pylab.xlabel('nilai t')
pylab.ylabel('nilai w')
pylab.title('grafik runge-kutta')
pylab.show()