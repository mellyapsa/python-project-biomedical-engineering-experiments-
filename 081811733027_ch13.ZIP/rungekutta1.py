#dwi melly aprilia sari / 081811733027
import math

#fungsi
def rungekutta(t,w):
    return (E/R)-(w/(R*C))
def exact(b):
    return C*E*(1-math.exp(-b/(R*C)))

#inisialisasi
a=0.0
b=2
h=0.1
N=round((b-a)/h)
t=0.0
w=0.0
E=12
C=5e-6
R=8e5

#perhtungan runge-kutta
for i in range (0,N):
    k1=h*rungekutta(t,w)
    k2=h*rungekutta(t+(h/2),w+(k1/2))
    k3=h*rungekutta(t+h,w-k1+2*k2)
    w=w+((k1+4*k2+k3)/6)
    t=t+h
    y_exact=exact(b)
    error=math.fabs(w-y_exact)
    print('x = ', round(t,2), 'y = ', w, 'error = ',error)
