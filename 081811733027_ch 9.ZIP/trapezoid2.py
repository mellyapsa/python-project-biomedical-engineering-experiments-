from math import sin,pi
import math
L=91.44
mu=0.01;
d=0.1
R=10
rho=1
alpha=64*L*mu/((d**2)*rho)
g=981
f = lambda z:1/(-alpha + math.sqrt((alpha**2)+(8*g*(z+L))))

a=5
b=50
c=abs(b-a)
h=0.001
n=round((b-a)/h)
S=0.5*(f(a)+f(b))

for i in range(1,n):
    S += f(a + i * h)
integral = h * S

t = ((8*(R**2))/(d**2))*integral
print('t(s)= ', t)
exact=f(b)-f(a)
selisih=exact-integral
print('exact=', exact)
error=math.fabs(selisih/exact)
print('error= ', error)