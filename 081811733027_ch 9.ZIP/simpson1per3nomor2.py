import math
L=91.44
mu=0.01;
d=0.1
R=10
rho=1
alpha=64*L*mu/((d**2)*rho)
g=981
f = lambda z:(1/(-alpha + math.sqrt((alpha**2)+(8*g*(z+L)))))

a=5
b=50
c=abs(b-a)
h=0.001
n=round((b-a)/h)
sum=f(a)+f(b)
fak=2

for i in range (1,n-1):
    x=a+(i*h)
    if (fak==2):
        fax=4
    else:
        fak=4
sum=sum+fak*f(x)

int=h/3*sum
integral=((8*R**2)/d**2)*int
print('t(s) =',integral)
exact=f(b)-f(a)
print('exact=', exact)
error=math.fabs(exact-integral)
print('error= ', error)