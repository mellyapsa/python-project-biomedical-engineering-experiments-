import math
f = lambda t:1-(2.718281828**((-12.5/78.5)*t))
a=0
b=12
h=0.001
n=round((b-a)/h)
g=9.8
m=78.5
c=12.5
S=f(a)+f(b)

for i in 1,2,(n-1):
    S += 4*f(a+(i*h))
for i in 2,2,(n-2):
    S += 2*f(a+i*h)

integral = (h/3)*S
x = (g*m/c)*integral
print('jarak sky diver jatuh= ' , x)
exact=f(b)-f(a)
print('exact=', exact)
error=math.fabs(x-exact)
print('error= ', error)

