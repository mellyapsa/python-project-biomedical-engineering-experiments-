import math
f = lambda t:(1-(2.718281828**((-12.5/78.5)*t)))
a=0
b=12
h=0.001
n=round((b-a)/h)
g=9.8
m=78.5
c=12.5
fa=f(a)
fb=f(b)
sum=f(a)+f(b)

for i in range (1,n-1):
    x=a+(i*h)
    sum=sum+2*f(x)
int = sum*h/2

integral = (g*m/c)*int
print('jarak sky diver jatuh= ', integral)
exact=f(b)-f(a)
selisih=exact-integral
print('exact=', exact)
error=math.fabs(selisih/exact)
print('error= ', error)