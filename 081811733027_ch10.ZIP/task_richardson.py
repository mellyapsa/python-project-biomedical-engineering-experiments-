#dwi melly aprilia sari
#081811733027
import math
x=[0.8, 0.9, 1.0, 1.2, 1.3, 1.4, 1.5, 1.6]
fx=[2.22554, 2.45960, 2.71828, 3.32011, 3.66929, 4.05519, 4.48168, 4.95303]

print(x)
angka=eval(input('masukkan nilai x yang diinginkan ='))

for i in range (0,len(x)):
    if x[i]>=angka:
        urutan=i
        break

x1=x[urutan-1]
x2=x[urutan+2]
h=(x2-x1)/4
fx1=fx[urutan-1]
fx2=fx[urutan+2]
d2h=((fx2-fx1)/(4*h))
err1=math.fabs(d2h-3.32011)
print('x1=', x1)
print('x2=', x2)
print('2h=', 2*h)
print('D(h)',d2h)
print('error = ',err1)

x3=x[urutan-3]
x4=x[urutan+4]
h=(x4-x3)/8
fx3=fx[urutan-3]
fx4=fx[urutan+4]
d4h=((fx4-fx3)/(8*h))
err2=math.fabs(d4h-3.32011)
print('x1=', x3)
print('x2=', x4)
print('4h=', 4*h)
print('D(4h)',d4h)
print('error = ',err2)

n=4
turunan1=d2h+((d2h-d4h)/15)
print('f0_turunan',turunan1)
er=math.fabs(turunan1-3.32011)
print('error = ',er)