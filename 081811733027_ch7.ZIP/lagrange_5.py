#dwi melly aprilia sari-081811733027
import numpy
import matplotlib.pyplot as plt
#inisialisasi
x = numpy.array([100, 80, 65, 60])
y = numpy.array([180, 160, 100, 90])
hasil = numpy.poly1d([0.0])

#interpolasi lagrange
for i in range(0, len(x)):
    numer = numpy.poly1d([1.0])
    denumer = 1.0
    for j in range(0, len(x)):
        if i != j:
            numer = numer*numpy.poly1d([1.0, -x[j]])
            denumer = denumer*(x[i]-x[j])
    hasil = hasil+(numer/denumer)*y[i]

#print hasil persamaan, dan nilai y hasil subtitusi
print('hasil interpolasi lagrange adalah y=')
print(hasil)

#plot hasil
x_lagrange = numpy.arange(min(x)-9, max(x)+6, 0.01)
y_lagrange = hasil(x_lagrange)
plt.xlabel('x')
plt.ylabel('y')
plt.grid(True)
for i in range(0, len(x)):
    plt.plot(x[i], y[i], 'yo')
plt.plot(x_lagrange, y_lagrange, 'k-')
plt.axis([min(x_lagrange), max(x_lagrange), min(y_lagrange)-1, max(y_lagrange)+1])
plt.show()