#dwi melly aprilia sari-081811733027
import numpy
import matplotlib.pyplot as plt
#inisialisasi
x = numpy.array([0.1, 0.3, 0.5, 0.7, 0.9, 1.1, 1.3])
y = numpy.array([0.03, 0.067, 0.148, 0.248, 0.320, 0.518, 0.697])
t = numpy.array([0.365, 0.512, 0.621, 0.715])
a = numpy.array([-0.5, 1.7])
hasil = numpy.poly1d([0.0])
#interpolasi lagrange
for i in range(0, len(x)):
    numer = numpy.poly1d([1.0])
    denumer = 1.0
    for j in range(0, len(x)):
        if i != j:
            numer = numer*numpy.poly1d([1.0, -x[j]])
            denumer = denumer*(x[i]-x[j])
    hasil = hasil+(numer/denumer)*y[i]
#menentukan y hasil subtitusi nilai t pada persamaan. catatan: t= x[n]
yy=hasil(t)
yyy=hasil(a)
#print hasil persamaan, dan nilai y hasil subtitusi
print('hasil interpolasi lagrange adalah y=')
print(hasil)
print('hasil nilai y dari t= ')
print(yy)
print(yyy)
#plot hasil
x_lagrange = numpy.arange(min(x), max(x), 0.01)
y_lagrange = hasil(x_lagrange)
plt.xlabel('x')
plt.ylabel('y')
plt.grid(True)
for i in range(0, len(x)):
    plt.plot(x[i], y[i], 'yo')
for i in range(0, len(t)):
    plt.plot(t[i], yy[i], 'r*')
for i in range(0, len(a)):
    plt.plot(a[i], yyy[i], 'r*')
plt.plot(x_lagrange, y_lagrange, 'k-')
plt.axis([min(x_lagrange), max(x_lagrange), min(y_lagrange), max(y_lagrange)])
plt.show()