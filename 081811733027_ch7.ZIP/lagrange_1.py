#dwi melly aprilia sari-081811733027
import numpy
import matplotlib.pyplot as plt
x = numpy.array([0.1, 0.3, 0.5, 0.7, 0.9, 1.1, 1.3])
y = numpy.array([0.03, 0.067, 0.148, 0.248, 0.320, 0.518, 0.697])
hasil = numpy.poly1d([0.0])
#interpolasi lagrange
for i in range(0, len(x)):
    numer = numpy.poly1d([1.0])
    denumer = 1.0
    for j in range(0, len(x)):
        if i != j:
            numer = numer*numpy.poly1d([1.0, -x[j]])
            denumer = denumer*(x[i]-x[j])
    hasil = hasil+(numer/denumer)*y[i]
#menampilkan hasil
print('hasil interpolasi lagrange adalah y=')
print(hasil)
#plot hasil
x_lagrange = numpy.arange(min(x), max(x), 0.01)
y_lagrange = hasil(x_lagrange)
plt.xlabel('x')
plt.ylabel('y')
plt.grid(True)
for i in range(0, len(x)):
    plt.plot([x[i]], [y[i]], 'yo')
plt.plot(x_lagrange, y_lagrange, 'k-')
plt.axis([min(x_lagrange), max(x_lagrange), min(y_lagrange), max(y_lagrange)])
plt.show()